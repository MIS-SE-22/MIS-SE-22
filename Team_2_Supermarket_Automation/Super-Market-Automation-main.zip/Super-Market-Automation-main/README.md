Supermarket Automation Project Introduction 

 

Group Members: 

Onur Nacar

Çağatay Ayhan 

Umut Secenoğlu 

Mehmet Emin Durukan 

Kemal Yüksel 

Yusuf Berk Uray

 

Our Aim: Make an easy-to-use supermarket automation 

Our Goal: To make an automation that keeps the product purchase and sales record for supermarkets, where the stock status can be easily controlled, the number of returns and the total profit can be learned. 

 

 

Programming Language: Python 

Tools We Use:Sqlite,LucidChart(For Uml Diagrams) 

 

Processes 

We held our first meeting on 20.11.2021. In our first meeting, we talked about the purpose of the project. Our first idea was to make an library automation 

Our aim in library automation was to make an automation that would keep track of purchased books and show the dates of borrowed books and book returners. 

But we gave up on this thought after many indecisive ideas. Finally we decided to do supermarket automation 

 

 

 

Tasks of group members in the process of building automation 

We know that division of labor accelerates the process and is very important in application development, but since we did not have enough experience yet, everyone helped each stage of the project instead of division of labor. 

In this way, we were able to get the results we wanted.
