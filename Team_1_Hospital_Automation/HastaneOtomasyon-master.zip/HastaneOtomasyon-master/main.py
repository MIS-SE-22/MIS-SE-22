from PyQt5.QtWidgets import QApplication
from otomation_qui_py import Otomation

app = QApplication([])
window = Otomation()
window.show()
app.exec_()
