from PyQt5.QtWidgets import *
import sys
from Hakkinda.hakkindaui_python import Ui_Form


class Hakkinda(QWidget):
    def __init__(self,parent=None):
        super().__init__()

        self.ui = Ui_Form()
        self.ui.setupUi(self)

        linkTemplate = '<a href={0}>{1}</a>'

        tolgaGithub = linkBaglanti(self)
        tolgaGithub.setText(linkTemplate.format('https://Github.com/tolgaboroglu',
                                                'Github Tolga'))
        tolgaGithub.move(350, 65)

        elifGithub = linkBaglanti(self)
        elifGithub.setText(linkTemplate.format('https://Github.com/elifsenaekiz', 'Github Elif'))
        elifGithub.move(350, 100)

        betulGithub = linkBaglanti(self)
        betulGithub.setText(linkTemplate.format('https://Github.com/betulguler', 'Github Betül'))
        betulGithub.move(350, 135)

        yusufGithub = linkBaglanti(self)
        yusufGithub.setText(linkTemplate.format('https://Github.com/psychopose1', 'Github Yusuf'))
        yusufGithub.move(350, 170)

        tugberkGithub = linkBaglanti(self)
        tugberkGithub.setText(linkTemplate.format('https://Github.com', 'Github Tuğberk'))
        tugberkGithub.move(350, 205)

        melihGithub = linkBaglanti(self)
        melihGithub.setText(linkTemplate.format('https://Github.com/melihmerall', 'Github Melih'))
        melihGithub.move(350, 240)

class linkBaglanti(QLabel):
    def __init__(self, parent=None):
        super().__init__()
        self.setStyleSheet('font-size: 22px')
        self.setOpenExternalLinks(True)
        self.setParent(parent)




