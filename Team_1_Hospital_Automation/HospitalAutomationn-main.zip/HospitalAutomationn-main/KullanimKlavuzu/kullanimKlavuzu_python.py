# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:/Users/melih/PycharmProjects/pythonProject/KullanimKlavuzu/kullanimKlavuzu.ui'
#
# Created by: PyQt5 UI code generator 5.6
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(614, 346)
        Form.setMinimumSize(QtCore.QSize(614, 346))
        Form.setMaximumSize(QtCore.QSize(614, 346))
        self.label = QtWidgets.QLabel(Form)
        self.label.setGeometry(QtCore.QRect(20, 80, 521, 241))
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(Form)
        self.label_2.setGeometry(QtCore.QRect(20, 30, 221, 31))
        self.label_2.setObjectName("label_2")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Kullanım Klavuzu"))
        self.label.setText(_translate("Form", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600;\">Giriş Ekranı : </span><span style=\" font-size:10pt;\">Admin Tc ve Şifre kullanarak sisteme giriş yapılmaktadır. </span></p><p><span style=\" font-size:10pt;\">Default sistem giriş bilgileri, Tc No: 12345678910 şifre: 1234</span></p><p><span style=\" font-size:10pt;\">(Güvenliğiniz için İlk Girişten sonra Default Bilgileri siliniz. )</span></p><p><span style=\" font-size:10pt; font-weight:600;\">Admin Paneli : </span><span style=\" font-size:10pt;\">Sisteme kayıtlı olmayan hastalara randevu</span></p><p><span style=\" font-size:10pt;\">oluşturalamaz! İlk önce hastanın sisteme kayıt olması gerekli.</span></p><p><span style=\" font-size:10pt; font-weight:600;\">Randevu ve Hasta Arama : </span><span style=\" font-size:10pt;\">Tc No girdiğiniz hastanın randevu </span></p><p><span style=\" font-size:10pt;\">bilgilerini sorgulayabilirsiniz.</span><span style=\" text-decoration: underline;\"><br/></span></p><p><span style=\" text-decoration: underline;\"><br/></span></p></body></html>"))
        self.label_2.setText(_translate("Form", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:600; color:#00007f;\">Kullanım Detayları</span></p></body></html>"))

import icons_rc
