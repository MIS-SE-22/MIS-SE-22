# Hospital Automation - BASİC TYPE
Hospital data automation. There is Python Source Code. You can download and you can examine.<br>
<br>

## Information
We used PyQt5 technology with Qt designer. Explanations are written on the codes. <br/>
This is a desktop application that records the entered information into the database.

## Table of contents
* [General info](#general-info)
* [Screenshots](#screenshots)
* [Technologies](#technologies)
* [Contact](#contact)

## General info

The program was written to be used in the patient admission department for the atu hospital.
Its main purpose is to keep patient information, doctor information and appointment information in the database.

## Screenshots
![Uploading ](https://r.resimlink.com/wD8O.png)
![Uploading ](https://r.resimlink.com/Mh6gV1W.png)
![Uploading ](https://r.resimlink.com/tKXRP.png)
![Uploading ](https://r.resimlink.com/c5Fa.png)
![Uploading ](https://r.resimlink.com/F0Dtp1On.png)
![Uploading ](https://r.resimlink.com/lX5x.png)

## Technologies
* Python - 3.9 version
* PyQt5 
* Qt Designer - 5.11 version

## Contact

[![Linkedin Badge](https://img.shields.io/badge/-melihmerall-blue?style=flat-square&logo=Linkedin&logoColor=white&link=https://www.linkedin.com/in/melihmerall/)](https://www.linkedin.com/in/melihmerall/) <br> [![Twitter Badge](https://img.shields.io/badge/-@melihmerall-1ca0f1?style=flat-square&labelColor=1ca0f1&logo=twitter&logoColor=white&link=https://twitter.com/melihmerall)](https://twitter.com/melihmerall) <br>  [![Facebook Badge](https://img.shields.io/badge/-@melihmeralll-3b5998?style=flat-square&labelColor=3b5998&logo=facebook&logoColor=white&link=https://www.facebook.com/melihmeralll/)](https://www.facebook.com/melihmeralll/) <br>  [![Instagram Badge](https://img.shields.io/badge/-@melihmerall-D7008A?style=flat-square&labelColor=D7008A&logo=Instagram&logoColor=white&link=https://www.instagram.com/melih.merall/)](https://www.instagram.com/melih.merall/)
