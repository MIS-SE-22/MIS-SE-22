from PyQt5.QtWidgets import *

from Admin.adminPage import AdminPage
from Hakkinda.hakkinda import Hakkinda
from KullanimKlavuzu.kullanimKlavuzu import KullanimKlavuzu

import sqlite3

from LoginPage.qt_designer_python import Ui_MainWindow

baglanti = sqlite3.connect("./hospital.db")
curs = baglanti.cursor()
class Otomation(QMainWindow):

    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.ui.adminGiris_Button.clicked.connect(self.adminGiris)
        self.admin_page = AdminPage()

        self.ui.hakkindaMenu.triggered.connect(self.hakkinda)
        self.hakkindaa = Hakkinda()

        self.ui.kullanimKlavuzu.triggered.connect(self.kullanimKlavuzu)
        self.kullanimKlavuzuu = KullanimKlavuzu()
        self.defaultAdminEkle()




#----------  Admin Olarak Giriş Yapmasını Bu fonksiyon ile Sağladık -----------#
#------------------------------------------------------------------------------#
    def hakkinda(self):
        self.hakkindaa.show()
    def kullanimKlavuzu(self):
        self.kullanimKlavuzuu.show()

    def defaultAdminEkle(self):
        curs.execute("SELECT * FROM Admin")
        res = curs.fetchall()
        if res == []:
            curs.execute("INSERT INTO Admin(Tc_No,Password) values(12345678910,'1234')")
        else:
            return AdminPage

            baglanti.commit()

    def adminGiris(self):
        tcNo = self.ui.adminTcno.text()
        sifre = self.ui.adminSifre.text()
        curs.execute("SELECT Tc_No,Password From Admin Where Tc_No=? and Password=?",(tcNo,sifre,))
        sonuc = curs.fetchall()
        if sonuc == [] or tcNo == "" or len(tcNo)!=11 or sifre =="":
            QMessageBox.warning(self, "UYARI!", "Tc No veya Şifre Hatalı!")
        else:
            self.admin_page.show()
            self.close()











