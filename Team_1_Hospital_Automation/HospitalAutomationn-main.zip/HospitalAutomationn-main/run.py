from PyQt5.QtWidgets import QApplication
from LoginPage.LoginPage import Otomation

app = QApplication([])
window = Otomation()
window.show()
app.exec_()



