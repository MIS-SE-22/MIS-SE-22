import sqlite3
from PyQt5 import QtCore
from PyQt5.QtWidgets import *


from Admin.admin_page_python import Ui_AdminPage
from LoginPage import LoginPage

baglanti = sqlite3.connect("hospital.db")
curs = baglanti.cursor()

class AdminPage(QWidget):

    def __init__(self):
        super().__init__()

        self.ui = Ui_AdminPage()
        self.ui.setupUi(self)

        ##################################################################################
        #-----------------------  Signal Slot Bağlantıları -------------------------#
        ##################################################################################

        self.ui.aHastaEkle.clicked.connect(self.hastaEkle)
        self.ui.aHastaListele.clicked.connect(self.hastaListele)
        self.ui.aHastaSil.clicked.connect(self.hastaSil)

        self.ui.aDoktorEkle.clicked.connect(self.doktorEkle)
        self.ui.aDoktorListele.clicked.connect(self.doktorListele)
        self.ui.aDoktorSil.clicked.connect(self.doktorSil)

        self.ui.aAdminEkle.clicked.connect(self.adminEkle)
        self.ui.aAdminSil.clicked.connect(self.adminSil)
        self.ui.aAdminListele.clicked.connect(self.adminListele)

        self.ui.aAdminCikis_1.clicked.connect(self.cikis)
        self.ui.aAdminCikis_2.clicked.connect(self.cikis)
        self.ui.aAdminCikis_3.clicked.connect(self.cikis)

        self.ui.aKlinikEkle.clicked.connect(self.klinikEkle)
        self.ui.aKlinikListele.clicked.connect(self.klinikListele)
        self.ui.aKlinikSil.clicked.connect(self.klinikSil)

        self.ui.randevuAl_Button.clicked.connect(self.randevuEkle)
        self.ui.randevuBul_Button.clicked.connect(self.randevuListele)
        self.ui.randevuIptal_Button.clicked.connect(self.randevuSil)


        self.ui.randevuAraButton.clicked.connect(self.randevuAra)
        self.ui.aHastaAra.clicked.connect(self.hastaAra)


    ##################################################################################

        # geri butonu için oluşturalan yapı, dönülecek sayfanın sınıfından nesne üretip aşağıda yazdıgım
        # backToPage fonksiyonunda ulaşıp tekar gösterme işlemi yaptırmak istedim.

        # self.loginPage = LoginPage.Otomation()

        #Fonksiyon çalışır hale gelince program hata veriyor. Hatayı görmek için alt satırdaki '#' işaretini kaldırın.

        #self.backToPage()

        self.ui.hastaCikis.clicked.connect(self.cikis)
        self.sehirEkle()

    #Fonksiyonun amacı, mevcut sayfayı gizle/kapat, ve loginPage'i göster.
    def backToPage(self):
        self.hide()
        self.loginPage.show()

    ##################################################################################



    ##################################################################################


    ##################################################################################
    #-------------- Hasta Ekleme, silme ve listeleme fonksiyonları -----------------#
    ##################################################################################
    def hastaEkle(self):
         aHastaTc = self.ui.aHastaTc.text()
         aHastaIsmSy = self.ui.aHastaIsmSy.text()
         aHastaDt = self.ui.aHastaDt.text()
         aHastaSehir = self.ui.aHastaSehir.currentText()
         aHastaTel = self.ui.aHastaTel.text()
         aHastaAdres = self.ui.aHastaAdres.toPlainText()

         if aHastaTc == "" or aHastaIsmSy == "" or aHastaDt == "" or aHastaSehir == "" or aHastaAdres == "" \
                 or aHastaTc == "" or aHastaTel == "" or len(aHastaTel) != 11 or len(aHastaTc) != 11:
             QMessageBox.information(self, "UYARI!", "Lütfen Tüm alanları eksiksiz doldurun. \n\n"
                                                     "Örnek Tel: 0 530 xxx xx xx (11 Hane) \n"
                                                     "Örnek Tc: 12345678911 (11 Hane)")
         else:
             curs.execute("INSERT INTO HospitalPatientList(Tc_No,Name_Surname,Birth_Date,Birth_Place,Phone_Number,Adress)"
                          " values(?,?,?,?,?,?)", (aHastaTc, aHastaIsmSy, aHastaDt, aHastaSehir, aHastaTel, aHastaAdres))
             baglanti.commit()
         self.ui.aHastaTc.clear()
         self.ui.aHastaIsmSy.clear()
         self.ui.aHastaTel.clear()
         self.ui.aHastaAdres.clear()

    def hastaListele(self):
        while self.ui.aHastaBilgi.rowCount() > 0:
            self.ui.aHastaBilgi.removeRow(0)
        baglanti = 'SELECT * FROM HospitalPatientList'
        res = curs.execute(baglanti)
        for row_index, row_data in enumerate(res):
            self.ui.aHastaBilgi.insertRow(row_index)
            for colm_index, colm_data in enumerate(row_data):
                self.ui.aHastaBilgi.setItem(row_index, colm_index, QTableWidgetItem(str(colm_data)))
        return

    def hastaSil(self):
        con = "SELECT * FROM HospitalPatientList"
        res = curs.execute(con)
        for row in enumerate(res):
            if row[0] == self.ui.aHastaBilgi.currentRow():
                data = row[1]
                tcNo = data[1]
                nameSurname = data[2]
                birthDate = data[3]
                birthPlace = data[4]
                phoneNumber = data[5]
                adress = data[6]
                curs.execute("DELETE FROM HospitalPatientList WHERE Tc_No=? AND Name_Surname=? AND Birth_Date=?"
                             " AND Birth_Place=? AND Phone_Number=? AND Adress=?",
                             (tcNo, nameSurname, birthDate, birthPlace, phoneNumber, adress,))
                baglanti.commit()
                self.hastaListele()
        return

    def hastaAra(self):
        araTc = self.ui.aHastaTc.text()
        araSehir = self.ui.aHastaSehir.currentText()
        while self.ui.aHastaBilgi.rowCount() > 0:
            self.ui.aHastaBilgi.removeRow(0)
        curs.execute("SELECT * FROM HospitalPatientList "
                           "WHERE Tc_No=? OR Birth_Place=? ",(araTc,araSehir,))
        res=curs.fetchall()
        if (araTc != "" and len(araTc) == 11) or (araSehir != "" and res != []) :
            for row_index, row_data in enumerate(res):
                self.ui.aHastaBilgi.insertRow(row_index)
                for colm_index, colm_data in enumerate(row_data):
                    self.ui.aHastaBilgi.setItem(row_index, colm_index, QTableWidgetItem(str(colm_data)))
            return
            self.ui.aHastaTc.clear()
        else:
            QMessageBox.warning(self, "HATA!", "TcNo ve Şehire Ait Hasta Bulunamadı!")

    ##################################################################################
    #---------------  Doktor Ekleme, silme ve listeleme fonksiyonları --------------#
    ##################################################################################

    def doktorEkle(self):
        doktorIsm = self.ui.aDoktorIsm.text()
        doktorKlinik = self.ui.aDoktorKlinik.currentText()

        if doktorIsm == "":
            QMessageBox.warning(self, "UYARI!", "Lütfen Tüm alanları eksiksiz doldurun!")
        else:
            curs.execute("INSERT INTO Doctors(Doctor_Name_Surname,KlinikID)"
                         " values(?,?)", (doktorIsm, doktorKlinik))
            baglanti.commit()
        self.ui.aDoktorIsm.clear()

    def doktorListele(self):
        while self.ui.aDoktorBilgi.rowCount() > 0:
            self.ui.aDoktorBilgi.removeRow(0)
        res = curs.execute('SELECT Doctor_Name_Surname,DoctorID,KlinikName,KlinikID From Clinics as c '
                     'inner join Doctors as d USING (KlinikID)  ')

        for row_index, row_data in enumerate(res):
            self.ui.aDoktorBilgi.insertRow(row_index)
            for colm_index, colm_data in enumerate(row_data):
                self.ui.aDoktorBilgi.setItem(row_index, colm_index, QTableWidgetItem(str(colm_data)))
        return

    def doktorSil(self):
        con = "SELECT * FROM Doctors"
        res = curs.execute(con)
        for row in enumerate(res):
            if row[0] == self.ui.aDoktorBilgi.currentRow():
                data = row[1]
                doktorIsm = data[1]
                klinik = data[2]
                curs.execute("DELETE FROM Doctors WHERE Doctor_Name_Surname=? AND KlinikID=? ",
                             (doktorIsm, klinik,))
                baglanti.commit()
                self.doktorListele()
        return

    ##################################################################################
    #-----------------  Admin Ekleme, silme ve listeleme fonksiyonları --------------#
    ##################################################################################

    def adminEkle(self):
        adminTc = self.ui.aAdminTc.text()
        adminSifre = self.ui.aAdminSifre.text()

        if adminTc == "" or adminSifre == "" or len(adminTc) != 11:
            QMessageBox.warning(self, "UYARI!", "Lütfen Tüm alanları eksiksiz doldurun!")
        else:
            curs.execute("INSERT INTO Admin(Tc_No,Password)"
                         " values(?,?)", (adminTc, adminSifre))
            baglanti.commit()
        self.ui.aAdminTc.clear()
        self.ui.aAdminSifre.clear()

    def adminListele(self):
        while self.ui.aAdminBilgi.rowCount() > 0:
            self.ui.aAdminBilgi.removeRow(0)
        baglanti = 'SELECT * FROM Admin'
        res = curs.execute(baglanti)
        for row_index, row_data in enumerate(res):
            self.ui.aAdminBilgi.insertRow(row_index)
            for colm_index, colm_data in enumerate(row_data):
                self.ui.aAdminBilgi.setItem(row_index, colm_index, QTableWidgetItem(str(colm_data)))
        return

    def adminSil(self):
        answer = QMessageBox.question(self, "BİLGİ", "İşlemi yapmak istediğinize emin misiniz ?"
                                      , QMessageBox.Yes | QMessageBox.No)
        if answer == QMessageBox.Yes:
            con = "SELECT * FROM Admin"
            res = curs.execute(con)
            for row in enumerate(res):
                if row[0] == self.ui.aAdminBilgi.currentRow():
                    data = row[1]
                    adminTc = data[0]
                    adminSifre = data[1]
                    curs.execute("DELETE FROM Admin WHERE Tc_No=? AND Password=? ",
                                 (adminTc, adminSifre,))
                    baglanti.commit()
                    self.adminListele()
        else:
            return AdminPage
        return

    ##################################################################################
    # --------  Klinik Ekle,Listele,Sil Fonksiyonlarımızı tanımladık.  -------------#
    ##################################################################################
    def klinikEkle(self):
        klinikNo = self.ui.aKlinikIsm.text()
        klinikIsm= self.ui.aKlinikNo.text()

        if klinikNo == "" or klinikIsm == "":
            QMessageBox.warning(self, "UYARI!", "Lütfen Tüm alanları eksiksiz doldurun!")
        else:
            curs.execute("INSERT INTO Clinics(KlinikID,KlinikName) "
                         "values(?,?)", (klinikNo, klinikIsm))
            baglanti.commit()
        self.ui.aKlinikIsm.clear()
        self.ui.aKlinikNo.clear()

    def klinikListele(self):
        while self.ui.aklinikbilgi.rowCount() > 0:
            self.ui.aklinikbilgi.removeRow(0)
        baglanti = 'SELECT * FROM Clinics'
        res = curs.execute(baglanti)
        for row_index, row_data in enumerate(res):
            self.ui.aklinikbilgi.insertRow(row_index)
            for colm_index, colm_data in enumerate(row_data):
                self.ui.aklinikbilgi.setItem(row_index, colm_index, QTableWidgetItem(str(colm_data)))
        return

    def klinikSil(self):
        answer = QMessageBox.question(self, "BİLGİ", "İşlemi yapmak istediğinize emin misiniz ?"
                                      , QMessageBox.Yes | QMessageBox.No)
        if answer == QMessageBox.Yes:
            con = "SELECT * FROM Clinics"
            res = curs.execute(con)
            for row in enumerate(res):
                if row[0] == self.ui.aklinikbilgi.currentRow():
                    data = row[1]
                    klinikNo = data[0]
                    klinikIsm = data[1]
                    curs.execute("DELETE FROM Clinics WHERE KlinikID=? AND KlinikName=? ",
                                 (klinikNo, klinikIsm,))
                    baglanti.commit()
                    self.klinikListele()
        else:
            return AdminPage
        return

    ##################################################################################
    # -----------------  Randevu Ekleme, silme ve listeleme fonksiyonları --------------#
    ##################################################################################
    def randevuEkle(self):

        rHastaTc = self.ui.rHastaTcNo.text()
        rHastaKlinik = self.ui.rHastaKlinik.currentText()
        rHastaDoktor = self.ui.rHastaDoktor.currentText()
        rTarih = self.ui.randevuTarih.selectedDate().toString(QtCore.Qt.ISODate)
        rSaat=self.ui.timeEdit.text()
        curs.execute("SELECT Tc_No FROM HospitalPatientList WHERE Tc_No=?",(rHastaTc,))
        tcNo = curs.fetchall()
        if rHastaTc == "" or rHastaKlinik == ""  or len(rHastaTc) != 11 :
            QMessageBox.warning(self, "UYARI!", "Lütfen Tüm alanları eksiksiz doldurun!")
        elif tcNo == []:
            QMessageBox.warning(self, "HATA!", "Hasta Bulunamadı! Lütfen hastayı sisteme kaydedin.")
        else:
            curs.execute("INSERT INTO Appointments (Tc_No,KlinikID,DoctorID,Dates,rSaat) values(?,?,?,?,?)",
                         (rHastaTc, rHastaKlinik, rHastaDoktor, rTarih, rSaat))
            QMessageBox.information(self, "BİLGİ", "Randevun Oluşturuldu!")
            baglanti.commit()
        self.ui.rHastaTcNo.clear()

    def randevuListele(self):
        while self.ui.randevuBilgiHasta.rowCount() > 0:
            self.ui.randevuBilgiHasta.removeRow(0)
        res = curs.execute('SELECT Name_Surname,Tc_No,KlinikName,Doctor_Name_Surname,Dates,rSaat '
                           'From Appointments as a '
                     'inner join Clinics as c ON a.KlinikID=c.KlinikID '
                     'inner join Doctors as d ON d.DoctorID=a.DoctorID '
                           'inner join HospitalPatientList as h Using (Tc_No)')
        for row_index, row_data in enumerate(res):
            self.ui.randevuBilgiHasta.insertRow(row_index)
            for colm_index, colm_data in enumerate(row_data):
                self.ui.randevuBilgiHasta.setItem(row_index, colm_index, QTableWidgetItem(str(colm_data)))
        #return

    def randevuSil(self):
        con = "SELECT * FROM Appointments"
        res = curs.execute(con)
        for row in enumerate(res):
            if row[0] == self.ui.randevuBilgiHasta.currentRow():
                data = row[1]
                TcNo = data[1]
                Klinik = data[2]
                Doktor = data[3]
                tarih = data[4]
                saat = data[5]
                curs.execute("DELETE FROM Appointments WHERE Tc_No=? AND KlinikID=? AND DoctorID=? AND Dates=? AND rSaat=?",
                             (TcNo, Klinik, Doktor, tarih,saat,))
                baglanti.commit()
                self.randevuListele()
        return

    def randevuAra(self):
        araTc = self.ui.rHastaTcNo.text()
        while self.ui.randevuBilgiHasta.rowCount() > 0:
            self.ui.randevuBilgiHasta.removeRow(0)
        res = curs.execute('SELECT Name_Surname,Tc_No,KlinikName,Doctor_Name_Surname,Dates,rSaat '
                           'From Appointments as a '
                     'inner join Clinics as c ON a.KlinikID=c.KlinikID '
                     'inner join Doctors as d ON d.DoctorID=a.DoctorID '
                           'inner join HospitalPatientList as h Using (Tc_No) WHERE Tc_No=?',(araTc,))
        if araTc =="":
            QMessageBox.warning(self,"HATA!","Lütfen Hasta TC no giriniz.")
        else:
            for row_index, row_data in enumerate(res):
                self.ui.randevuBilgiHasta.insertRow(row_index)
                for colm_index, colm_data in enumerate(row_data):
                    self.ui.randevuBilgiHasta.setItem(row_index, colm_index, QTableWidgetItem(str(colm_data)))
            return
            self.ui.rHastaTcNo.clear()

    ##################################################################################
    #--------  Sehirleri Databaseden CheckBox'a çektik ve çıkış fonksiyonu yazdık  -------------#
    ##################################################################################

    def sehirEkle(self):
        curs.execute("SELECT name FROM tr_city")
        sehirler = curs.fetchall()

        for i in sehirler:
            self.ui.aHastaSehir.addItems(i)

    def cikis(self):
        answer = QMessageBox.question(self, "BİLGİ", "İşlemi yapmak istediğinize emin misiniz ?"
                                      , QMessageBox.Yes | QMessageBox.No)
        if answer == QMessageBox.Yes:
            baglanti.close()
            self.close()

        else:
            return AdminPage





